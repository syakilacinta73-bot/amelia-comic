
let daftarPenggunaAmelia = JSON.parse(
    localStorage.getItem("users")
) || [];

// LOGIN
function login() {
    let username = document.getElementById("loginUser").value.trim();
    let password = document.getElementById("loginPass").value;

    let user = daftarPenggunaAmelia.find(u =>
        u.username === username &&
        u.password === password
    );

    if (user) {
        localStorage.setItem("loginUser", user.username);
        localStorage.setItem("loginName", user.nama);
        tampilkanWebsite();
        alert("Login berhasil!");
    } else {
        alert("Username atau password salah!");
    }
}

// REGISTER
function register() {
    let nama = document.getElementById("regName").value.trim();
    let username = document.getElementById("regUser").value.trim();
    let password = document.getElementById("regPass").value;

    if (!nama || !username || !password) {
        alert("Semua data harus diisi!");
        return;
    }

    if (password.length < 6) {
        alert("Password minimal 6 karakter!");
        return;
    }

    if (daftarPenggunaAmelia.some(u => u.username === username)) {
        alert("Username sudah digunakan!");
        return;
    }

    daftarPenggunaAmelia.push({
        nama: nama,
        username: username,
        password: password
    });

    localStorage.setItem(
        "users",
        JSON.stringify(daftarPenggunaAmelia)
    );

    alert("Pendaftaran berhasil!");
    showLogin();
}

// TAMPILKAN WEBSITE
function tampilkanWebsite() {
    document.getElementById("loginPage").classList.add("hidden");
    document.getElementById("registerPage").classList.add("hidden");
    document.getElementById("website").classList.remove("hidden");

    document.getElementById("namaPengguna").innerText =
        localStorage.getItem("loginName");

    document.getElementById("userName").innerText =
        "👤 " + localStorage.getItem("loginUser");
}

// LOGOUT
function logout() {
    if (confirm("Yakin ingin logout?")) {
        localStorage.removeItem("loginUser");
        localStorage.removeItem("loginName");
        location.reload();
    }
}

// PINDAH HALAMAN
function showRegister() {
    document.getElementById("loginPage").classList.add("hidden");
    document.getElementById("registerPage").classList.remove("hidden");
}

function showLogin() {
    document.getElementById("registerPage").classList.add("hidden");
    document.getElementById("loginPage").classList.remove("hidden");
}

// PENCARIAN KOMIK
function cariKomik() {
    let keyword = document.getElementById("searchComic").value.toLowerCase();

    document.querySelectorAll(".comic-card").forEach(card => {
        let judul = card.querySelector("h3").innerText.toLowerCase();
        card.style.display = judul.includes(keyword) ? "block" : "none";
    });
}

// DETAIL KOMIK
function lihatDetail(judul, isi) {
    document.getElementById("detailJudul").innerText = judul;
    document.getElementById("detailIsi").innerText = isi;
    document.getElementById("detail").classList.remove("hidden");
}

function tutupDetail() {
    document.getElementById("detail").classList.add("hidden");
}

// CEK LOGIN
if (localStorage.getItem("loginUser")) {
    let user = daftarPenggunaAmelia.find(u =>
        u.username === localStorage.getItem("loginUser")
    );

    if (user) {
        tampilkanWebsite();
    } else {
        localStorage.removeItem("loginUser");
        localStorage.removeItem("loginName");
    }
}
